---
name: Field Utility
colors:
  surface: '#faf9f5'
  surface-dim: '#dbdad6'
  surface-bright: '#faf9f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f4f0'
  surface-container: '#efeeea'
  surface-container-high: '#e9e8e4'
  surface-container-highest: '#e3e2df'
  on-surface: '#1b1c1a'
  on-surface-variant: '#524433'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ed'
  outline: '#857461'
  outline-variant: '#d8c3ad'
  surface-tint: '#835500'
  primary: '#835500'
  on-primary: '#ffffff'
  primary-container: '#f4a100'
  on-primary-container: '#613d00'
  inverse-primary: '#ffb955'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#00658c'
  on-tertiary: '#ffffff'
  tertiary-container: '#2abeff'
  on-tertiary-container: '#004a67'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffddb5'
  primary-fixed-dim: '#ffb955'
  on-primary-fixed: '#2a1800'
  on-primary-fixed-variant: '#633f00'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1b1b1c'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#c5e7ff'
  tertiary-fixed-dim: '#7fd0ff'
  on-tertiary-fixed: '#001e2d'
  on-tertiary-fixed-variant: '#004c6a'
  background: '#faf9f5'
  on-background: '#1b1c1a'
  surface-variant: '#e3e2df'
typography:
  h1:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-margin: 24px
  gutter: 16px
  stack-sm: 4px
  stack-md: 12px
  stack-lg: 24px
---

## Brand & Style

The design system is engineered for the modern field trade professional. It balances rugged reliability with high-end digital craftsmanship. The aesthetic is "Industrial Premium"—a style that prioritizes legibility and utility while maintaining an air of authoritative quality.

The UI avoids the "lightweight" feel of consumer apps, opting instead for a grounded, structural feel. It utilizes a Corporate/Modern foundation with subtle tactile elements, ensuring that every interaction feels intentional and sturdy. The interface is designed to evoke trust, clarity, and precision, reflecting the high-stakes nature of field trade services.

## Colors

The palette is anchored by a sophisticated interplay between warm darks and luminous ambers. 

- **Primary Action:** The Amber (#F4A100) is the "working light" of the application, used exclusively for primary interactions and critical state indicators.
- **Surfaces:** The Charcoal (#1E1E1E) provides a heavy, stable anchor for sidebars and navigation headers. It is strictly warm-toned to maintain harmony with the off-white background.
- **Background:** The Off-White (#F7F6F2) minimizes eye strain in varying field lighting conditions and distinguishes the app from generic pure-white software.
- **Status Badges:** Semantic colors are intentionally muted to ensure they don't compete with the primary amber CTA. They use high-contrast text on soft, desaturated backgrounds for maximum readability.

## Typography

The design system uses Inter for its exceptional clarity and technical appearance. 

The type hierarchy is strictly defined:
- **Headings & Labels:** Set at 600 weight to create a strong visual "skeleton" for forms and data tables.
- **Body Text:** Set at 400 weight for optimal long-form reading on mobile devices.
- **Micro-copy:** Labels use a slightly increased letter-spacing to ensure legibility when used in tight spaces like status badges or table headers.
- **Hierarchy:** High contrast in size and weight is used to guide the eye toward task completion.

## Layout & Spacing

The layout philosophy follows a rigid 8px grid system to maintain alignment and rhythm. 

- **Grid Model:** A fluid 12-column grid is used for desktop views, transitioning to a single-column stack on mobile with 24px outer margins.
- **Rhythm:** Vertical spacing relies on "Stack" units (sm, md, lg) to group related content. 
- **Density:** The design system balances information density for field use—elements are sized to be "tap-friendly" (minimum 44px height for buttons) while maintaining a refined, professional data density.

## Elevation & Depth

This design system uses a "Layered Tonal" approach to depth. Rather than relying on aggressive drop shadows, it uses:

- **Tonal Separation:** The dark sidebar sits at the lowest level, with the off-white main background layered on top. 
- **Refined Cards:** Cards use a subtle 1px border (#E5E5E1) and a soft, diffused shadow (Offset: 0, 4px; Blur: 12px; Opacity: 4%) to lift them from the background.
- **Interactive States:** Buttons and active cards utilize a more pronounced "press" effect, where the shadow tightens and the border darkens slightly to provide tactile feedback.
- **Overlays:** Modals and drawers use a 40% opacity charcoal overlay to dim the background and focus the user's attention.

## Shapes

The shape language is "Soft-Industrial." The choice of `Rounded` (Level 2) ensures that the interface feels modern and accessible without becoming overly "bubbly" or informal.

- **Standard Elements:** Buttons, input fields, and cards utilize a 0.5rem (8px) corner radius.
- **Large Containers:** Modals and large dashboard panels use 1rem (16px) or 1.5rem (24px) for a more architectural feel.
- **Nested Shapes:** When elements are nested (e.g., an image inside a card), the inner radius is always 4px smaller than the outer radius to maintain geometric harmony.

## Components

The component library is built for speed and durability in the field.

- **Buttons:** Primary buttons are Solid Amber (#F4A100) with Black text for maximum contrast. Secondary buttons use a Ghost style with a Charcoal border.
- **Input Fields:** Fields utilize the warm grey background but transition to a 2px Amber border on focus. Labels are always persistent above the field.
- **Status Badges:** These use a "Pill" shape with a 600-weight font. The colors must follow the muted semantic palette defined in the color section.
- **Cards:** The workhorse of the app. Every card must have a subtle border and a very soft shadow. Titles within cards are always H3 or Label-MD.
- **Sidebar:** The primary sidebar is Deep Charcoal. Nav items use the Amber color only for the "Active" indicator (a vertical bar on the left) and the icon color.
- **Action Sheets:** For mobile users, bottom-anchored action sheets replace traditional dropdowns to ensure one-handed operation is possible.